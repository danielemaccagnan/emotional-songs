import java.io.IOException;

import prog.io.*;
public class Main extends cercaBranoMusicale {

	public static void main(String[] args) {

System.out.println("cerca brano musicale --->  1");
System.out.println("visualizza emozioni --->2");
System.out.println("registrazione ---> 3");
System.out.println("login ---> 4");
System.out.println("crea una playlist ---> 5");
System.out.println("inserisci emozioni ---> 6");
ConsoleInputManager in = new ConsoleInputManager();
int numero = in.readInt();
while (numero>6||numero<1) {
	System.out.println("� stato inserito un numero non valido, riprova");
	numero = in.readInt();
}
if (numero==1) {
	System.out.println("ricerca tramite titolo ---> 1");
	System.out.println("ricerca tramite autore e anno ---> 2");
	int n1 = in.readInt();
	while(n1<1||n1>2) {
		System.out.println("� stato inserito un numero non valido, riprova");
		n1=in.readInt();
	}
	if(n1==1) {
		String titolo=in.readLine("inserisci il titolo della canzone");
		cercaBranoMusicale(titolo);
	}
	else if(n1==2) {
		String autore=in.readLine("inserisci l'autore della canzone");
		int anno = in.readInt("inserisci il titolo della canzone");
		cercaBranoMusicaleAnno(anno, autore);
		
	}
	
}

if (numero==3) {
	String nome = in.readLine("inserisci il nome");
	String cognome = in.readLine("inserisci il cognome");
	String codicefiscale = in.readLine("inserisci il codice fiscale");
	String indirizzo = in.readLine("inserisci l'indirizzo");
	int civico = in.readInt("inserisci il numero civico");
	int cap = in.readInt("inserisci il cap");
	String comune= in.readLine("inserisci il comune"); 
	String provincia=in.readLine("inserisci la provincia");
	String email=in.readLine("inserisci l'email");
	String userid=in.readLine("inserisci il nome utente");
	String password=in.readLine("inserisci la password"); 
	try {
		RegistrazioneNome(nome,cognome,codicefiscale,indirizzo,civico,cap,comune,provincia,email,userid,password);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
if(numero==5) {
	String nomeplaylist= in.readLine("inserisci il nome della playlist");
	try {
		RegistraPlaylist(nomeplaylist);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

if(numero==6) {
	try {
		inserisciEmozioniBrano();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

	}

	


}
