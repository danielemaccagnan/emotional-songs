import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import prog.io.ConsoleInputManager;
public class RegistraPlaylist extends InserisciEmozioni{

	/* public static void main(String[] args) throws IOException {
		RegistraPlaylist("nome playlist");

	} */
	public static void RegistraPlaylist(String nome) throws IOException {
		try {
		FileWriter fw = new FileWriter("C:\\Users\\danym\\Desktop\\ProgettoEmotionalMaps\\Playlist.dati.txt", true);
        fw.write(nome + "\n" + "\n");
        ConsoleInputManager in = new ConsoleInputManager();
        String path = "C:\\Users\\danym\\Desktop\\ProgettoEmotionalMaps\\UtentiRegistrati.dati.txt";
		BufferedReader reader;
		File file = new File(path);
		FileReader fr = new FileReader(file);
		reader = new BufferedReader(fr);
		String line = reader.readLine();
		String userid = in.readLine("inserisci il nome utente");
		String password = in.readLine("inserisci la password");
		String all = userid+ "/" + password;

		boolean login=true;
		while(line!=null) {
			 
			for(int i=0; i<all.length()-1;i++) {
				
				if(line.charAt(line.length()-1-i)!=all.charAt(all.length()-1-i)) {
					login=false;	
					
					
					
					
					
					
					
					 
				}
			}
			
			
			if(login==true) {
			
			try {
				boolean continua=true;
				fw.write(nome + "\n"+ "\n");
				
				System.out.println("accesso effettuato");
		        
				while(continua!=false) {
					
		        String titolo = in.readLine("inserisci il titolo");
		        fw.write(titolo + "\n");
		        
		       continua= in.readSiNo("vuoi inserire un'altra canzone?");
		        if(continua==false) {
		        	
		        	fw.write("playlist effettuata da " + userid);
		        fw.write("\n");
		        fw.close();
		        reader.close();
		        	}
				}
		        
		        
		        
		        
			} catch (Exception e) {
				e.printStackTrace();
		}
		} 
			line=reader.readLine();
		} 
		
		}catch (Exception e) {
			e.printStackTrace();
			
		} }
}

