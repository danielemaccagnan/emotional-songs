import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;

import java.io.BufferedReader;
import prog.io.*;
public class Registrazione extends RegistraPlaylist{

	public static void main(String[] args) throws IOException {
	
	RegistrazioneNome("daniele", "maccagnan", "mcd3nl022c933k", "viale risorgimento", 5,22100,"como", "co", "dany.macca95@gmail.com", "s", "s");
	//RegistrazioneNome("tommaso", "mariani", "tmsmrn", "viale cernobio", 8, 22100, "como", "co", "tomm@gmail.com", "user8", "Password789");

}
	public static void RegistrazioneNome(String nome, String cognome, String codicefiscale, String via, int numerocivico, int cap, String comune, String provincia, String email, String userid, String password) throws IOException {
		ConsoleInputManager in = new ConsoleInputManager ();
		try {
			
		
        FileWriter fw = new FileWriter("C:\\Users\\danym\\Desktop\\ProgettoEmotionalMaps\\UtentiRegistrati.dati.txt", true);
        boolean codfiscale=true;
        while(codicefiscale.length()!=16) {
        	System.out.println("inserire il codice fiscale correttamente");
        	codicefiscale=in.readLine();    
      	
        }
        if(codicefiscale.length()!=16) {
        	codfiscale=false;
        }
        boolean primacond=true;
      
        if(Character.isDigit(codicefiscale.charAt(6))==false||Character.isDigit(codicefiscale.charAt(7))==false||Character.isDigit(codicefiscale.charAt(9))==false||Character.isDigit(codicefiscale.charAt(10))==false||Character.isDigit(codicefiscale.charAt(12))==false||Character.isDigit(codicefiscale.charAt(13))==false||Character.isDigit(codicefiscale.charAt(14))==false) {
        	primacond=false;
        }
        
       for(int i=0;i<6;i++) {
    	   if(Character.isLetter(codicefiscale.charAt(i))==false) {
    		   primacond=false;
    		   break;
    	   }
       }
       if(Character.isLetter(codicefiscale.charAt(8))==false||Character.isLetter(codicefiscale.charAt(11))==false||Character.isLetter(codicefiscale.charAt(15))==false) {
    	   primacond=false;
       }
       boolean emaill=false;
       for(int i=0; i<email.length();i++) {
    	  
    	   if(email.charAt(i)=='@') {
    		   emaill=true;
    		   break;
    	   }
       }
        if(codfiscale==true&&primacond==true&&emaill==true) {
        fw.write(nome);
        fw.write("/"+ cognome);
        fw.write("/"+codicefiscale);
        fw.write("/"+via);
        fw.write("/"+numerocivico);
        fw.write("/"+cap);
        fw.write("/"+comune);
        fw.write("/"+provincia);
        fw.write("/"+email);
        fw.write("/"+userid);
        fw.write("/"+password);
        fw.write("\n");
        fw.close();
        
        
	
	
	
	} else {
		if(codfiscale==false||primacond==false) {
			System.out.println("codice fiscale errato");
		} else if(emaill==false) {
			System.out.println("formato email non valido");
		}
	}	if(codfiscale==true && primacond==true) {
		System.out.println("registrazione effettuata correttamente");
	}
        } catch (Exception e) {
		e.printStackTrace();
	}
		
		}
}		


