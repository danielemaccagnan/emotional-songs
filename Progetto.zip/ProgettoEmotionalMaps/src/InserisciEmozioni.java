import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import prog.io.ConsoleInputManager;

public class InserisciEmozioni {

	public static void main(String[] args) throws IOException {
		inserisciEmozioniBrano();
		
	}
public static void inserisciEmozioniBrano() throws IOException {
	try {
		FileWriter fw = new FileWriter("C:\\Users\\danym\\Desktop\\ProgettoEmotionalMaps\\Emozioni.dati.txt", true);
       
        ConsoleInputManager in = new ConsoleInputManager();
        String path = "C:\\Users\\danym\\Desktop\\ProgettoEmotionalMaps\\UtentiRegistrati.dati.txt";
		BufferedReader reader;
		File file = new File(path);
		FileReader fr = new FileReader(file);
		reader = new BufferedReader(fr);
		String line = reader.readLine();
		String userid = in.readLine("inserisci il nome utente");
		String password = in.readLine("inserisci la password");
		String all = userid+ "/" + password;
	
		boolean login=false;
		while(line!=null&&login==false) {
			 login=true;
			for(int i=0; i<all.length();i++) {
			
				if(line.charAt(line.length()-1-i)!=all.charAt(all.length()-1-i)) {
					login=false;
					break;
					
				}
			}
			
			
			if(login==true) {
			
			try {
				  String pathh = "C:\\Users\\danym\\Desktop\\ProgettoEmotionalMaps\\Playlist.dati.txt";
					BufferedReader readerr;
					File filee = new File(pathh);
					FileReader frr = new FileReader(filee);
					readerr = new BufferedReader(frr);
					String linee = readerr.readLine();
					boolean trovata=false;
		        String canzone = in.readLine("quale canzone vuoi ricercare?");
		     //   File a = new File("file.txt");
		        Scanner b = new Scanner(filee);
		        String now=null;
		        while((now=b.next())!=null)
		        {
		        	if(now.equals(canzone)) {
		        		trovata=true;
		        	System.out.println("canzone trovata, inserisci un emozione");	
		        	 break;
		        	 }
		        
		        
		        }
		        
		        if(trovata==true) {
		        	fw.write("\n"+canzone + "\n" + "\n");
		        	
		        	
		        	for(int i=0; i<9;i++) {
		        		String emozione = in.readLine("inserisci un'emozione");
		        		fw.write(emozione + " ");
		        		
		        		int numero=in.readInt("quanto da 1 a 5");
		        		while(numero<1||numero>5) {
		        			System.out.println("numero invalido");
		        			 numero=in.readInt("inserisci il nuovo numero");
		        		}
		        		fw.write(numero + " ");
		        		
		        		
		        	}
		        	fw.write("\n"+ "\n");
		        	fw.close();
		        	
		        	
		        		
		        	
		        }
		        
		        	} catch (Exception e) {
				e.printStackTrace();
		}
		} 
			line=reader.readLine();
		} 
		
		}catch (Exception e) {
			e.printStackTrace();
			
		} }
}
