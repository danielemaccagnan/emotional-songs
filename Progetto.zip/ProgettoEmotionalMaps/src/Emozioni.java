
enum Emozioni{
	Meraviglia,
	Solennit�,
	Tenerezza,
	Nostalgia,
	Calma,
	Forza,
	Gioia,
	Tenzione,
	Tristezza
}
